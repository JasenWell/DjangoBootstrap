# flex-box-demo Flex 布局示例

> 感谢阮一峰老师的教程 http://www.ruanyifeng.com/blog/2015/07/flex-grammar.html

本示例将教程上所有的布局都简单的实现了一遍，预览地址：http://static.vgee.cn/static/index.html
